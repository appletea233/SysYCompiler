package judge;

public class Judge {
    void judge(){

    }
}
