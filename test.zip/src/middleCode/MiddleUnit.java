package middleCode;

public class MiddleUnit {
    String name;
    int value;

    public MiddleUnit(String name) {
        this.name = name;
    }

    public MiddleUnit(String name, int value) {
        this.name = name;
        this.value = value;
    }
}
