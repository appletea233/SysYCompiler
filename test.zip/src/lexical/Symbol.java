package lexical;

import base.BaseUnit;

public class Symbol extends BaseUnit {
    public void construct(){
    }

    protected Symbol(String name, String content, int line){
        super(name, content, line);
    }
}
