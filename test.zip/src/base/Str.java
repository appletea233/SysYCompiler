package base;

public class Str extends Var{
    public String content;
    String cls = "str";

    public Str(String name, String content) {
        super(name);
        this.content = content;

    }
}
