package mips;

public class MipsCode {
}
